<?php
/*
Plugin Name: UpToLike Social Share Buttons
Plugin URI: https://uptolike.com/
Description: Uptolike Social Share Buttons - social bookmarking widget with sharing statistics.
Version: 1.4.5
Author: Uptolike Team
Author URI: https://uptolike.com/
*/

// Creating the widget

include 'widget_options.php';
