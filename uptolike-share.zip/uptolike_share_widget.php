<?php
/**
 * Plugin Name: UpToLike Social Share Buttons
 * Plugin URI: https://uptolike.com/
 * Description: Uptolike Social Share Buttons - social bookmarking widget with sharing statistics.
 * Version: 1.5.3
 * Requires at least: 4.1
 * Tested up to: 4.6.1
 * Author: Uptolike Team
 * Author URI: https://uptolike.com/
 *
 * @package UpToLike
 * @category Statistic
 * @author UptolikeTeam
 */

include 'widget_options.php';

